* source
https://github.com/DAToolset/ToolsForDataStandard/tree/main/WordExtractor


* refer
https://prodskill.com/ko/category/data-architecture-tools/word-extractor/
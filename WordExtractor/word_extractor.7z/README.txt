* Word Extractor source Github repository:
https://github.com/DAToolset/ToolsForDataStandard/tree/main/WordExtractor


* Word Extractor user guide(blog)
https://prodskill.com/ko/category/data-architecture-tools/word-extractor/